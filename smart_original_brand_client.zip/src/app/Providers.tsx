'use client'
import { QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { getQueryClient } from '@/app/get-query-client'
import { Toaster } from 'react-hot-toast';
import NextTopLoader from 'nextjs-toploader';

export default function Providers({ children }: { children: React.ReactNode }) {
  const queryClient = getQueryClient()

  return (
    <QueryClientProvider client={queryClient}>
      {children}
        <Toaster position="bottom-right" reverseOrder={false} />
        <NextTopLoader color="#000000"/>
      <ReactQueryDevtools />
    </QueryClientProvider>
  )
}
