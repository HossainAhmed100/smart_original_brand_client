import type { Metadata } from 'next'
import '@/styles/styles.scss'
import GlobalProvider from './GlobalProvider'
import ModalWishlist from '@/components/Modal/ModalWishlist'
import ModalSearch from '@/components/Modal/ModalSearch'
import ModalQuickview from '@/components/Modal/ModalQuickview'
import ModalCompare from '@/components/Modal/ModalCompare'
import 'sweetalert2/src/sweetalert2.scss'
import Providers from './Providers'

export const metadata: Metadata = {
  title: 'Smart Original Brand',
  description: 'Life Style Brand',
}

export default function RootLayout({children,}: {children: React.ReactNode}) {
  return (
    <GlobalProvider>
      <html lang="en">
        <body>
          <Providers>{children}</Providers>
          <ModalWishlist />
          <ModalSearch />
          <ModalQuickview />
          <ModalCompare />
        </body>
      </html>
    </GlobalProvider>
  )
}
