
export interface TestimonialType {
    id: string,
    category: string,
    title: string,
    name: string,
    avatar: string,
    date: string,
    address: string,
    description: string,
    images: Array<string>,
    star: number,
}