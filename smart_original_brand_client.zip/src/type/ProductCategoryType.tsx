export interface ProductCategoryType {
  _id: string,
  label: string,
  path: string,
  key: Number,
}